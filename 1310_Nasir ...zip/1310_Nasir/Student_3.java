
public class Student_3 extends Teacher{
  
	Student_3(String Name,int Roll, String Fa_name,String Mo_name,String Address)
	{
		super(Name,Roll, Fa_name, Mo_name,Address);
		
		   
	   }
	      void  Information() {
		      	 System.out.println("  ");
             System.out.println("Student_3 Information");
	    	 System.out.println("  Name :"+Name);
	    	 System.out.println("  Roll :"+Roll);

	    	 System.out.println("  Fa_name :"+Fa_name);
	    	 System.out.println("  Mo_name :"+Mo_name);
	    	 System.out.println("  Address :"+Address);
	      	 System.out.println("  ");


		}
	
}


