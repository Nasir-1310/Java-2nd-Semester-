
public class Test {
  public static void main(String[] args) {
	
	 Teacher info;
	 info=new student_1("Nasir Uddin",20,"Nazrul inslm","Nurjahan","Netrakina");
	 	info.Information();
	 
	 	info=new Student_2("Mustafizur Rahman Rakib",18,"Abdul Rajjak","Tasfia","Mymynsingh");
	 	info.Information();
	 	
	 	info=new Student_3("Amit kumar Roy",19,"Kamim Roy","Rahena","Kurigram");
	 	info.Information();
	 	
	 	
}
}
