package nominator_denominator;

public class class_con {
	int numerator;
	int denominator;
	int cal_numerator;
	int cal_denominator;
	class_con(int nomi,int deno){
		numerator=nomi;
		denominator=deno;
	}
	
	void add(class_con firstnum,class_con secondnum) {
		
		cal_numerator=firstnum.numerator*secondnum.denominator+secondnum.numerator*firstnum.denominator;
		cal_denominator=firstnum.denominator*secondnum.denominator;
		System.out.println("Summation is "+cal_numerator+"/"+cal_denominator);
	}
void sub(class_con firstnum,class_con secondnum) {
		
		cal_numerator=firstnum.numerator*secondnum.denominator-secondnum.numerator*firstnum.denominator;
		cal_denominator=firstnum.denominator*secondnum.denominator;
		System.out.println("Substruction is "+cal_numerator+"/"+cal_denominator);
	}
void multi(class_con firstnum,class_con secondnum) {
	
	cal_numerator=firstnum.numerator*secondnum.numerator;
	cal_denominator=firstnum.denominator*secondnum.denominator;
	System.out.println("Multiplation result  is "+cal_numerator+"/"+cal_denominator);
}
void div(class_con firstnum,class_con secondnum) {
	
	cal_numerator=firstnum.numerator*secondnum.denominator;
	cal_denominator=firstnum.denominator*secondnum.numerator;
	System.out.println("Divide result  is "+cal_numerator+"/"+cal_denominator);
}
void string(class_con firstnum,class_con secondnum) {
	int p=firstnum.numerator;
	String s=String.valueOf(firstnum.numerator);
	s=s+"/";
	s=s+firstnum.denominator;
	cal_denominator=firstnum.denominator*secondnum.numerator;
	System.out.println("String value for the firstnum  is "+s);
}
void floating_value(class_con firstnum,class_con secondnum) {
	
	double a=(double)firstnum.numerator/firstnum.denominator;
	System.out.println("Floating point value is "+a);
}
}
