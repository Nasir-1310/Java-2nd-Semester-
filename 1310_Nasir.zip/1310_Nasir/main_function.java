package nominator_denominator;

public class main_function {
public static void main(String[] args) {
	class_con firstnum=new class_con(1,2);
	class_con secondnum=new class_con(1,3);
	
	
	class_con result=new class_con(0,0);
	      result.add( firstnum,secondnum);
  
	      result.sub( firstnum,secondnum);
	      result.multi( firstnum,secondnum);
	      result.div( firstnum,secondnum);
	      result.string( firstnum,secondnum);
	      result.floating_value( firstnum,secondnum);
	
}
}
